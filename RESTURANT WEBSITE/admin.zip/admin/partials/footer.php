	<!------------------footer section start--------->
		<div class="footer">
		<div class="wrapper"><p class="text-center">2021 All right reserved.Food House Developed by <a href="#"> W.K.K.B.WEERASINGHE.</a></p>
			</div>
		</div>
		<!--------------footer section end-------------->
	
	
	
	</body>
</html>